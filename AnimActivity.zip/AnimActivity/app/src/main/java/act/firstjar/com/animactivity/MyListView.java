package act.firstjar.com.animactivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.provider.ContactsContract;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by admin on 2016/4/12.
 */
public class MyListView extends ListView implements AbsListView.OnScrollListener{

    private float clickPos;//记录第一次点下的Y轴坐标
    private boolean isEnable;//判断当前是否在刷新中，true不在，false在

    private LinearLayout headView;
    private TextView txt;
    private ImageView arrow;
    private ProgressBar progressbar;
    private LinearLayout layoutShow;
    private int headViewHeight;

    private Matrix matrix = new Matrix();

    private OnBaiduRefreshListener mOnRefreshListener;  //刷新接口

    public MyListView(Context context) {
        super(context);
        init(context);
    }

    public MyListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MyListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {

    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch(ev.getAction()){
            case MotionEvent.ACTION_DOWN:
                clickPos = ev.getY();//获取手指点下的位置Y坐标
                break;
            case MotionEvent.ACTION_MOVE:
                if(isEnable){//不在刷新中，可以刷新
                    if((int)(ev.getY()-clickPos) > headViewHeight){

                    }else {
                        headView.setPadding(0, -(int) (headViewHeight - (ev.getY() - clickPos)), 0, 0);
                        if((int)(ev.getY()-clickPos)*3/2 >= headViewHeight){
                            Bitmap bm = ((BitmapDrawable)getResources().getDrawable(R.drawable.xsearch_msg_pull_arrow_down)).getBitmap();
                            matrix.setRotate(180);
                            bm = Bitmap.createBitmap(bm,0,0,bm.getWidth(),bm.getHeight(),matrix,true);
                            arrow.setImageBitmap(bm);
                            txt.setText("松开立即刷新");
                        }else{

                        }
                    }
                }else{

                }

                break;
            case MotionEvent.ACTION_UP:
               // System.out.println("upY:" + ev.getY());
                if(isEnable){
                    if((int)(ev.getY()-clickPos)*3/2 >= headViewHeight){
                        Bitmap bm = ((BitmapDrawable)getResources().getDrawable(R.drawable.xsearch_msg_pull_arrow_down)).getBitmap();
                        matrix.setRotate(180);
                        bm = Bitmap.createBitmap(bm,0,0,bm.getWidth(),bm.getHeight(),matrix,true);
                        arrow.setImageBitmap(bm);
                        txt.setText("松开立即刷新");
                        headView.setPadding(0, 0, 0, 0);
                        layoutShow.setVisibility(View.GONE);
                        progressbar.setVisibility(View.VISIBLE);
                        mOnRefreshListener.onRefresh();
                        isEnable=false;
                    }else{
                        headView.setPadding(0, -headViewHeight, 0, 0);
                        isEnable=true;
                    }
                }else{

                }


                break;
        }
        return super.onTouchEvent(ev);
    }



    private void init(Context context){
        isEnable = true;
        setOverScrollMode(OVER_SCROLL_NEVER);
        setOnScrollListener(this);

        headView = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.head,this,false);
        measureView(headView);
        addHeaderView(headView);
        headViewHeight = headView.getMeasuredHeight();
        headView.setPadding(0,-headViewHeight,0,0);

        txt = (TextView) headView.findViewById(R.id.txt);
        arrow = (ImageView) headView.findViewById(R.id.arrow);
        progressbar = (ProgressBar) headView.findViewById(R.id.progressbar);
        layoutShow = (LinearLayout) headView.findViewById(R.id.layoutShow);

        System.out.println("height="+headViewHeight);
    }


    /**
     * 测量View
     * @param child
     */
    private void measureView(View child) {
        ViewGroup.LayoutParams p = child.getLayoutParams();
        if (p == null) {
            p = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        int childWidthSpec = ViewGroup.getChildMeasureSpec(0, 0 + 0, p.width);
        int lpHeight = p.height;
        int childHeightSpec;
        if (lpHeight > 0) {
            childHeightSpec = MeasureSpec.makeMeasureSpec(lpHeight,
                    MeasureSpec.EXACTLY);
        } else {
            childHeightSpec = MeasureSpec.makeMeasureSpec(0,
                    MeasureSpec.UNSPECIFIED);
        }
        child.measure(childWidthSpec, childHeightSpec);
    }

    public interface OnBaiduRefreshListener{
        void onRefresh();
    }
    /**
     * 回调接口，想实现下拉刷新的listview实现此接口
     * @param onRefreshListener
     */
    public void setOnBaiduRefreshListener(OnBaiduRefreshListener onRefreshListener){
        mOnRefreshListener = onRefreshListener;
    }

    public void onRefreshComplete(){
        isEnable = true;
        headView.setPadding(0, -headViewHeight, 0, 0);
        Bitmap bm = ((BitmapDrawable)getResources().getDrawable(R.drawable.xsearch_msg_pull_arrow_down)).getBitmap();
        matrix.setRotate(0);
        bm = Bitmap.createBitmap(bm,0,0,bm.getWidth(),bm.getHeight(),matrix,true);
        arrow.setImageBitmap(bm);
        txt.setText("下拉可以刷新");
        progressbar.setVisibility(View.GONE);
        layoutShow.setVisibility(View.VISIBLE);
    }

}

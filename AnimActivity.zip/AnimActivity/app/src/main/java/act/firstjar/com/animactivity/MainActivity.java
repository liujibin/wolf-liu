package act.firstjar.com.animactivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private Animation wheel,moveleft,moveRight,wheelrond;
    private ImageView sunImg;
    private Button startAnim,stopAnim,click;
    private ImageView bagImg,bImg;
    private ImageView leftWheel,rightWheel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wheel = AnimationUtils.loadAnimation(this,R.anim.round);
        moveleft = AnimationUtils.loadAnimation(this,R.anim.animation);
        moveRight = AnimationUtils.loadAnimation(this,R.anim.b);
        wheelrond = AnimationUtils.loadAnimation(this,R.anim.wheelround);

        leftWheel = (ImageView) findViewById(R.id.leftWheel);
        rightWheel = (ImageView) findViewById(R.id.rightWheel);
        sunImg = (ImageView) findViewById(R.id.sunImg);
        startAnim = (Button) findViewById(R.id.startAnim);
        stopAnim = (Button) findViewById(R.id.stopAnim);
        bagImg = (ImageView) findViewById(R.id.bagImg);
        bImg = (ImageView) findViewById(R.id.bImg);
        click = (Button) findViewById(R.id.click);
        startAnim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startAnim();
            }
        });
        stopAnim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                endAnim();
            }
        });
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,SecondActivity.class));
            }
        });
    }

    public void startAnim(){
        sunImg.startAnimation(wheel);
        bagImg.startAnimation(moveleft);
        bImg.startAnimation(moveRight);
        leftWheel.startAnimation(wheelrond);
        rightWheel.startAnimation(wheelrond);
    }

    public void endAnim(){
        sunImg.clearAnimation();
        bagImg.clearAnimation();
        bImg.clearAnimation();
        leftWheel.clearAnimation();
        rightWheel.clearAnimation();
    }
}

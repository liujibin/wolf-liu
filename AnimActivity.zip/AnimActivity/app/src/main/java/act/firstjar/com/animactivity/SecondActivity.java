package act.firstjar.com.animactivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by admin on 2016/4/12.
 */
public class SecondActivity extends Activity implements MyListView.OnBaiduRefreshListener{

    private SharedPreferences sp;
    private MyListView listView;
    private MyAdapter mAdapter;
    private List<Map<String,Object>> data = new ArrayList<Map<String,Object>>();


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch(msg.what){
                case 0x01:
                    System.out.println("in_hand");
                    mAdapter = new MyAdapter(SecondActivity.this,data);
                    listView.setAdapter(mAdapter);
                    listView.onRefreshComplete();
                    break;
            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        sp = getPreferences(Activity.MODE_PRIVATE);
        listView = (MyListView) findViewById(R.id.listView);

        for(int i = 0;i < 10;i++){
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("text","message"+i);
            data.add(map);
        }
        mAdapter = new MyAdapter(this,data);
        listView.setAdapter(mAdapter);
       listView.setOnBaiduRefreshListener(this);
    }

    @Override
    public void onRefresh() {
        System.out.println("--in");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);

                    data.clear();
                    for(int i = 0;i < 10;i++){
                        Map<String,Object> map = new HashMap<String,Object>();
                        map.put("text","test"+i);
                        data.add(map);
                    }

                    Message msg = new Message();
                    msg.what = 0x01;
                    handler.sendMessage(msg);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}

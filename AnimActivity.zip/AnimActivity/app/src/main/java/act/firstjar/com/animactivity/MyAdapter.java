package act.firstjar.com.animactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by admin on 2016/4/13.
 */
public class MyAdapter extends BaseAdapter{

    public List<Map<String,Object>> data = new ArrayList<Map<String,Object>>();
    private Context mContext;
    private LayoutInflater mLayoutInflater = null;
    private TextView tv;

    public MyAdapter(Context context,List<Map<String,Object>> d){
        mContext = context;
        mLayoutInflater = LayoutInflater.from(context);
        data = d;
    }


    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        if(null == view){
            view = mLayoutInflater.inflate(R.layout.list_item,parent,false);
            tv = (TextView) view.findViewById(R.id.tv);
        }

        tv.setText(data.get(position).get("text").toString());

        return view;
    }
}
